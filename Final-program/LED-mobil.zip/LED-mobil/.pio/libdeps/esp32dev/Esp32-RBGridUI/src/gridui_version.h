#pragma once

#define RB_GRIDUI_VERSION 0x040206

